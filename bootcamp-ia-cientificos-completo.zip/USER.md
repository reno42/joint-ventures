# USER.md - About Your Human

- **Name:** Renzo Perez Bartra
- **What to call them:** Renzo
- **Pronouns:** _(por definir)_
- **Timezone:** _(por definir)_
- **Notes:** Fundador de Futuraria

## Context

- **Project:** Futuraria (futuraria.com)
- **Stack:** n8n Community Edition v2.10.4 (Railway) + Supabase
- **Objetivo:** Gestionar Futuraria de forma autónoma mediante automatizaciones n8n y base de datos Supabase

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
