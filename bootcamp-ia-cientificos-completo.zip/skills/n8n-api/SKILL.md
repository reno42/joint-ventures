---
name: n8n-api
description: Operate n8n via its public REST API. Workflow management, executions, troubleshooting. Works with self-hosted and n8n Cloud.
---

## n8n Public REST API

Use this skill to drive n8n programmatically via REST API.

## Configuration
Set env vars:
export N8N_API_BASE_URL="https://tu-instancia.up.railway.app/api/v1"
export N8N_API_KEY="tu-api-key"

Auth header: X-N8N-API-KEY: $N8N_API_KEY

## Quick actions

### List workflows
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/workflows" | jq '.data[] | {id, name, active}'

### Get workflow details
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/workflows/{id}"

### Activate/Deactivate
curl -s -X POST -H "X-N8N-API-KEY: $N8N_API_KEY" -H "Content-Type: application/json" -d '{}' "$N8N_API_BASE_URL/workflows/{id}/activate"
curl -s -X POST -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/workflows/{id}/deactivate"

### List executions (recent + failed)
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/executions?limit=10" | jq '.data[] | {id, workflowId, status, startedAt}'
curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/executions?status=error&limit=5"

### Retry failed execution
curl -s -X POST -H "X-N8N-API-KEY: $N8N_API_KEY" -H "Content-Type: application/json" -d '{"loadWorkflow":true}' "$N8N_API_BASE_URL/executions/{id}/retry"

### Trigger webhook
curl -s -X POST "$N8N_API_BASE_URL/../webhook/{path}" -H "Content-Type: application/json" -d '{"key":"value"}'

### Health check
ACTIVE=$(curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/workflows?active=true" | jq '.data | length')
FAILED=$(curl -s -H "X-N8N-API-KEY: $N8N_API_KEY" "$N8N_API_BASE_URL/executions?status=error&limit=100" | jq '[.data[] | select(.startedAt > (now - 86400 | todate))] | length')
echo "Active: $ACTIVE | Failed (24h): $FAILED"

## Debug a failed run
1. List failed executions to get ID
2. Fetch execution details, identify failing node
3. Review node parameters and input data
4. Suggest fix based on error

## Notes
- Webhook URLs != API URLs (no API key header needed)
- Execution records may be pruned by retention settings
