---
name: n8n-workflow-automation
description: Designs and outputs n8n workflow JSON with robust triggers, idempotency, error handling, logging, retries, and human-in-the-loop review queues.
---

# n8n workflow automation with retries, logging, and review queues

## PURPOSE
Designs and outputs n8n workflow JSON with robust triggers, idempotency, error handling, logging, retries, and human-in-the-loop review queues.

## WHEN TO USE
- Build an n8n workflow that runs on schedule and sends summaries
- Add error handling, retries, and review queues
- Create webhook workflows that log every run
- Make flows idempotent to prevent duplicates
- Instrument with audit logs and human approval steps
- DO NOT USE: for code-only automations, bypassing security, hiding audit trails

## INPUTS
- REQUIRED: Workflow intent (trigger type + schedule/timezone + success criteria), Targets (where to write results)
- OPTIONAL: Existing n8n workflow JSON, sample payloads, dedup keys

## OUTPUTS
- Default: workflow design spec (nodes, data contracts, failure modes)
- If requested: workflow.json (n8n importable) + runbook.md

## WORKFLOW
1. Clarify trigger (cron/webhook/manual, schedule/timezone, concurrency)
2. Define data contract (input schema, required fields, validation)
3. Design idempotency (dedup keys, storage)
4. Add observability (run_id, logging, status tracking)
5. Error handling (per-node error branches, retry with backoff)
6. Human-in-the-loop review queue (failed items to queue for approval)
7. No silent failure gates
8. Output workflow JSON + runbook if requested
9. STOP AND ASK if destinations, dedup keys, credentials, or privileges are unclear

## OUTPUT FORMAT
```json
{
 "name": "<workflow name>",
 "nodes": [{"name": "Trigger", "type": "n8n-nodes-base.cron", "parameters": {}, "position": [0,0]}],
 "connections": {},
 "settings": {},
 "active": false
}
```

## SAFETY
- Read-only by default, only emit JSON when requested
- No secrets in JSON, use env vars/credential names only
- Always include audit logging + failure notifications
- Prefer least privilege
