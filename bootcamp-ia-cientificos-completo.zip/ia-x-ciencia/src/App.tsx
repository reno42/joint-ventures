import './index.css'

function App() {
  return (
    <div className="relative min-h-screen">
      {/* ============ VIDEO BACKGROUND ============ */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0"
        src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260314_131748_f2ca2a28-fed7-44c8-b9a9-bd9acdd5ec31.mp4"
      />

      {/* ============ NAVIGATION ============ */}
      <nav className="relative z-10 flex items-center justify-between px-8 py-6 max-w-7xl mx-auto">
        <a
          href="#"
          className="text-3xl tracking-tight text-white"
          style={{ fontFamily: "'Instrument Serif', serif" }}
        >
          IA × Ciencia
          <sup className="text-xs ml-1 opacity-50">®</sup>
        </a>

        <div className="hidden md:flex items-center gap-8">
          <a href="#inicio" className="text-sm text-white transition-colors">
            Inicio
          </a>
          <a href="#modelos" className="text-sm text-[hsl(240,4%,66%)] hover:text-white transition-colors">
            Modelos IA
          </a>
          <a href="#nichos" className="text-sm text-[hsl(240,4%,66%)] hover:text-white transition-colors">
            Nichos
          </a>
          <a href="#formatos" className="text-sm text-[hsl(240,4%,66%)] hover:text-white transition-colors">
            Formatos
          </a>
          <a href="#nosotros" className="text-sm text-[hsl(240,4%,66%)] hover:text-white transition-colors">
            Nosotros
          </a>
          <a
            href="#contacto"
            className="liquid-glass rounded-full px-6 py-2.5 text-sm text-white hover:scale-[1.03] transition-transform"
          >
            Quiero participar
          </a>
        </div>
      </nav>

      {/* ============ HERO ============ */}
      <section
        id="inicio"
        className="relative z-10 flex flex-col items-center justify-center text-center px-6 pt-32 pb-40 py-[90px]"
      >
        <h1
          className="animate-fade-rise text-5xl sm:text-7xl md:text-8xl leading-[0.95] tracking-[-2.46px] max-w-7xl font-normal"
          style={{ fontFamily: "'Instrument Serif', serif" }}
        >
          Donde la <em className="not-italic text-[hsl(240,4%,66%)]">ciencia</em>
          <br />
          acelera con <em className="not-italic text-[hsl(240,4%,66%)]">inteligencia artificial.</em>
        </h1>

        <p className="animate-fade-rise-delay text-[hsl(240,4%,66%)] text-base sm:text-lg max-w-2xl mt-8 leading-relaxed">
          Bootcamps para científicos que quieren comprimir años de investigación en semanas.
          Modelos IA preentrenados. Sin código. Sin instalación. Resultados reales.
        </p>

        <a
          href="#contacto"
          className="animate-fade-rise-delay-2 liquid-glass rounded-full px-14 py-5 text-base text-white mt-12 hover:scale-[1.03] transition-transform cursor-pointer inline-block"
        >
          Quiero participar
        </a>

        <div className="animate-fade-rise-delay-3 mt-16 flex items-center gap-3 text-sm text-[hsl(240,4%,66%)]">
          <span className="opacity-70">Una alianza de</span>
          <span className="text-white font-medium">NETI</span>
          <span className="opacity-40">×</span>
          <span className="text-white font-medium">Futuraria</span>
        </div>
      </section>

      {/* ============ IMPACT STATS ============ */}
      <section className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { stat: '1000×', label: 'Más rápido que DFT', detail: 'Simulación molecular con MACE' },
            { stat: '30 meses', label: 'vs. 15 años', detail: 'Fármaco de Insilico Medicine' },
            { stat: '2.2M', label: 'Estructuras predichas', detail: 'Google DeepMind GNoME' },
            { stat: '2M+', label: 'Investigadores', detail: 'usando AlphaFold' },
          ].map((item, i) => (
            <div
              key={i}
              className="liquid-glass rounded-2xl p-6 text-center"
            >
              <div
                className="text-3xl sm:text-4xl text-white mb-2"
                style={{ fontFamily: "'Instrument Serif', serif" }}
              >
                {item.stat}
              </div>
              <div className="text-sm text-white font-medium mb-1">{item.label}</div>
              <div className="text-xs text-[hsl(240,4%,66%)]">{item.detail}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ============ PROBLEM ============ */}
      <section className="relative z-10 max-w-5xl mx-auto px-6 pb-32 text-center">
        <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">El problema</p>
        <h2
          className="text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight mb-8"
          style={{ fontFamily: "'Instrument Serif', serif" }}
        >
          La investigación científica tiene un problema de{' '}
          <em className="not-italic text-[hsl(240,4%,66%)]">velocidad</em>
        </h2>
        <p className="text-[hsl(240,4%,66%)] text-lg max-w-3xl mx-auto leading-relaxed">
          Un fármaco tarda 10-15 años en llegar al mercado. Un nuevo material puede tomar décadas.
          La IA puede comprimir esos tiempos a meses. Los modelos ya existen — pero nadie enseña
          a los científicos a usarlos.
        </p>
      </section>

      {/* ============ MODELS ============ */}
      <section id="modelos" className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">Herramientas</p>
          <h2
            className="text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight"
            style={{ fontFamily: "'Instrument Serif', serif" }}
          >
            Modelos IA que puedes usar{' '}
            <em className="not-italic text-[hsl(240,4%,66%)]">hoy</em>
          </h2>
          <p className="text-[hsl(240,4%,66%)] text-lg max-w-2xl mx-auto mt-6 leading-relaxed">
            Sin ser programador. Sin instalar nada. Estos modelos funcionan con datos cero del usuario — solo necesitas tu pregunta científica.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            {
              icon: '🔬',
              title: 'Simulación Molecular',
              models: ['MACE-MP/OFF', 'Meta OMol25/UMA', 'SchNet / DimeNet'],
              desc: 'Simulación 1000× más rápida que DFT. Funciona out-of-the-box.',
              color: 'from-purple-500/20 to-blue-500/20',
            },
            {
              icon: '🧱',
              title: 'Materiales y Catálisis',
              models: ['IBM FM4M', 'Open Catalyst (Meta)', 'GNoME (DeepMind)'],
              desc: 'Descubrimiento de baterías, catalizadores, semiconductores.',
              color: 'from-cyan-500/20 to-teal-500/20',
            },
            {
              icon: '💊',
              title: 'Biomedicina y Fármacos',
              models: ['AlphaFold 3', 'ESM (Meta)', 'Deep Origin / Balto'],
              desc: 'Estructura de proteínas, drug discovery, diseño de enzimas.',
              color: 'from-pink-500/20 to-rose-500/20',
            },
            {
              icon: '🌐',
              title: 'Plataformas Sin Código',
              models: ['Rowan (web)', 'AlphaFold Server', 'Google Colab'],
              desc: 'Login con Google → pegas molécula → resultado. Cero instalación.',
              color: 'from-emerald-500/20 to-green-500/20',
            },
          ].map((card, i) => (
            <div key={i} className={`liquid-glass rounded-2xl p-8 bg-gradient-to-br ${card.color}`}>
              <div className="text-4xl mb-4">{card.icon}</div>
              <h3
                className="text-2xl text-white mb-3"
                style={{ fontFamily: "'Instrument Serif', serif" }}
              >
                {card.title}
              </h3>
              <p className="text-[hsl(240,4%,66%)] text-sm mb-4">{card.desc}</p>
              <div className="flex flex-wrap gap-2">
                {card.models.map((m, j) => (
                  <span
                    key={j}
                    className="text-xs px-3 py-1 rounded-full bg-white/5 text-white/80 border border-white/10"
                  >
                    {m}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ============ NICHES ============ */}
      <section id="nichos" className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">Nichos industriales</p>
          <h2
            className="text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight"
            style={{ fontFamily: "'Instrument Serif', serif" }}
          >
            ¿Dónde impacta más{' '}
            <em className="not-italic text-[hsl(240,4%,66%)]">la IA</em>?
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { icon: '🔋', name: 'Baterías', stars: 5, models: 'IBM FM4M · MACE', desc: 'Transición energética, demanda explosiva' },
            { icon: '💊', name: 'Fármacos', stars: 5, models: 'AlphaFold · ESM · Deep Origin', desc: 'Mayor impacto, 2M+ usuarios' },
            { icon: '🧪', name: 'Catalizadores H₂', stars: 4, models: 'Open Catalyst · MACE', desc: 'Urgencia climática, datasets masivos' },
            { icon: '🧬', name: 'Enzimas', stars: 4, models: 'ESM · AlphaFold', desc: 'Bioplásticos, biocombustibles' },
            { icon: '🔩', name: 'Aleaciones', stars: 4, models: 'MACE-MP · IBM FM4M', desc: 'Aeroespacial, automotive' },
            { icon: '🏭', name: 'Semiconductores', stars: 4, models: 'GNoME · IBM FM4M', desc: 'Materiales avanzados para chips' },
          ].map((nicho, i) => (
            <div key={i} className="liquid-glass rounded-2xl p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-3xl">{nicho.icon}</span>
                <span className="text-yellow-400 text-sm">
                  {'★'.repeat(nicho.stars)}{'☆'.repeat(5 - nicho.stars)}
                </span>
              </div>
              <h3
                className="text-xl text-white mb-1"
                style={{ fontFamily: "'Instrument Serif', serif" }}
              >
                {nicho.name}
              </h3>
              <p className="text-[hsl(240,4%,66%)] text-sm mb-3">{nicho.desc}</p>
              <div className="text-xs text-cyan-400/80">{nicho.models}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ============ FORMATS ============ */}
      <section id="formatos" className="relative z-10 max-w-6xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">Formatos</p>
          <h2
            className="text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight"
            style={{ fontFamily: "'Instrument Serif', serif" }}
          >
            Elige tu nivel de{' '}
            <em className="not-italic text-[hsl(240,4%,66%)]">inmersión</em>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { emoji: '🔥', duration: '1 día', name: 'Flash Sprint', price: '$80–150', items: ['Intro + herramientas sin código', 'Hands-on con tu investigación', 'Primer modelo ejecutado'] },
            { emoji: '🚀', duration: '2 días', name: 'Weekend Bootcamp', price: '$200–400', items: ['Día 1: Modelos IA + casos', 'Día 2: Prototipar + pitch', 'Prototipo funcional'] },
            { emoji: '🎓', duration: '1 semana', name: 'Intensivo', price: '$800–2,000', items: ['Simulación molecular', 'Análisis de datos', 'Transformación completa'] },
            { emoji: '🏗️', duration: '8–12 sem', name: 'Programa', price: '$3,000–8,000', items: ['Basado en I-Corps + ETI', '100 entrevistas a clientes', 'Lanzar startup'] },
          ].map((format, i) => (
            <div key={i} className="liquid-glass rounded-2xl p-8 text-center">
              <div className="text-5xl mb-4">{format.emoji}</div>
              <div
                className="text-3xl text-white mb-1"
                style={{ fontFamily: "'Instrument Serif', serif" }}
              >
                {format.duration}
              </div>
              <h3 className="text-lg text-white font-medium mb-1">{format.name}</h3>
              <div className="text-cyan-400 text-sm font-medium mb-4">{format.price} USD</div>
              <ul className="text-left text-sm text-[hsl(240,4%,66%)] space-y-2">
                {format.items.map((item, j) => (
                  <li key={j} className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-0.5">→</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* ============ ABOUT / JV ============ */}
      <section id="nosotros" className="relative z-10 max-w-5xl mx-auto px-6 pb-32">
        <div className="text-center mb-16">
          <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">Joint Venture</p>
          <h2
            className="text-4xl sm:text-5xl md:text-6xl leading-tight tracking-tight"
            style={{ fontFamily: "'Instrument Serif', serif" }}
          >
            NETI <span className="text-[hsl(240,4%,66%)]">×</span> Futuraria
          </h2>
          <p className="text-[hsl(240,4%,66%)] text-lg max-w-2xl mx-auto mt-6 leading-relaxed">
            Dos ecosistemas complementarios. Argentina aporta el talento científico y la innovación regional.
            Perú aporta la regulación IA más avanzada de LATAM y operaciones tech.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="liquid-glass rounded-2xl p-8">
            <h3
              className="text-2xl text-white mb-4"
              style={{ fontFamily: "'Instrument Serif', serif" }}
            >
              🇦🇷 NETI — No Está Todo Inventado
            </h3>
            <ul className="space-y-3 text-[hsl(240,4%,66%)] text-sm">
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Red de científicos e instituciones argentinas</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Contactos CONICET, INTI, universidades</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Metodología ETI (prototipado compulsivo)</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Innovación regional (Pergamino, Venado Tuerto)</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>AgTech y ciencia aplicada</li>
            </ul>
          </div>
          <div className="liquid-glass rounded-2xl p-8">
            <h3
              className="text-2xl text-white mb-4"
              style={{ fontFamily: "'Instrument Serif', serif" }}
            >
              🇵🇪 Futuraria
            </h3>
            <ul className="space-y-3 text-[hsl(240,4%,66%)] text-sm">
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Stack tecnológico (n8n + Supabase)</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Consultoría ENIA (regulación IA Perú)</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Automatización y agentes IA</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Operaciones y marketing digital</li>
              <li className="flex items-start gap-2"><span className="text-cyan-400">✦</span>Escalabilidad LATAM</li>
            </ul>
          </div>
        </div>
      </section>

      {/* ============ CONTACT ============ */}
      <section id="contacto" className="relative z-10 max-w-2xl mx-auto px-6 pb-32">
        <div className="liquid-glass rounded-3xl p-10 sm:p-14">
          <div className="text-center mb-10">
            <p className="text-sm text-[hsl(240,4%,66%)] tracking-widest uppercase mb-4">Contacto</p>
            <h2
              className="text-3xl sm:text-4xl text-white mb-3"
              style={{ fontFamily: "'Instrument Serif', serif" }}
            >
              ¿Quieres participar?
            </h2>
            <p className="text-[hsl(240,4%,66%)] text-sm">
              Déjanos tus datos y te contactamos. Próximo bootcamp: pronto.
            </p>
          </div>

          <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">Nombre completo</label>
                <input
                  type="text"
                  placeholder="Tu nombre"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-white/30 transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">Email</label>
                <input
                  type="email"
                  placeholder="tu@email.com"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-white/30 transition-colors"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">Institución</label>
                <input
                  type="text"
                  placeholder="CONICET, UBA, PUCP..."
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-white/30 transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">Área de investigación</label>
                <select className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-white/30 transition-colors appearance-none">
                  <option value="" className="bg-[hsl(201,100%,13%)]">Selecciona...</option>
                  <option value="materiales" className="bg-[hsl(201,100%,13%)]">Ciencia de Materiales</option>
                  <option value="farmacos" className="bg-[hsl(201,100%,13%)]">Fármacos / Biomedicina</option>
                  <option value="biologia" className="bg-[hsl(201,100%,13%)]">Biología / Proteínas</option>
                  <option value="quimica" className="bg-[hsl(201,100%,13%)]">Química / Catálisis</option>
                  <option value="agro" className="bg-[hsl(201,100%,13%)]">AgTech / Agronomía</option>
                  <option value="otro" className="bg-[hsl(201,100%,13%)]">Otro</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">Formato de interés</label>
              <select className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm focus:outline-none focus:border-white/30 transition-colors appearance-none">
                <option value="" className="bg-[hsl(201,100%,13%)]">Selecciona...</option>
                <option value="flash" className="bg-[hsl(201,100%,13%)]">🔥 Flash Sprint (1 día)</option>
                <option value="weekend" className="bg-[hsl(201,100%,13%)]">🚀 Weekend Bootcamp (2 días)</option>
                <option value="intensivo" className="bg-[hsl(201,100%,13%)]">🎓 Intensivo (1 semana)</option>
                <option value="programa" className="bg-[hsl(201,100%,13%)]">🏗️ Programa completo (8-12 sem)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-[hsl(240,4%,66%)] mb-2">¿Qué investigación quieres acelerar?</label>
              <textarea
                rows={4}
                placeholder="Cuéntanos sobre tu investigación y cómo crees que la IA podría ayudarte..."
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-white/30 transition-colors resize-none"
              />
            </div>
            <button
              type="submit"
              className="liquid-glass w-full rounded-full py-4 text-white text-base font-medium hover:scale-[1.02] transition-transform cursor-pointer"
            >
              Quiero participar
            </button>
          </form>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="relative z-10 text-center pb-12 px-6">
        <div className="h-px bg-white/10 max-w-4xl mx-auto mb-8" />
        <p className="text-sm text-[hsl(240,4%,66%)]">
          <span className="text-white">NETI</span> (No Está Todo Inventado) × <span className="text-white">Futuraria</span> — IA × Ciencia
        </p>
        <p className="text-xs text-[hsl(240,4%,66%)] mt-2 opacity-50">
          <a href="https://noestatodoinventado.com" className="hover:text-white transition-colors">noestatodoinventado.com</a>
          {' · '}
          <a href="https://futuraria.com" className="hover:text-white transition-colors">futuraria.com</a>
        </p>
        <p className="text-xs text-[hsl(240,4%,66%)] mt-4 opacity-30">2026 — Hecho con 🧠 y ⚡</p>
      </footer>
    </div>
  )
}

export default App
