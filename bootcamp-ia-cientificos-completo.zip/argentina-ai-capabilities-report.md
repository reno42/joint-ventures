# Argentine Scientific & Technological Institutions: AI/Tech Capabilities Report

## 1. CONICET (Consejo Nacional de Investigaciones Científicas y Técnicas)

**Role:** Argentina's premier scientific research council, funding ~10,000 researchers across all disciplines.

### AI/Tech Spin-offs & Innovations

- **Retinar** — A CONICET/UNICEN spin-off (from PLADEMA Institute, Tandil) using AI for retinal screening to prevent avoidable blindness. Started research in 2013, company constituted ~2025. Uses AI + human-in-the-loop validation. 60,000+ studies validated, 95.5% sensitivity, 40+ retinograph models compatible. Integration via API into public health systems.
- **José Ignacio Orlando (CONICET Associate Researcher)** — Leads AI Labs at Arionkoder through a CONICET STAN (Servicio Tecnológico de Alto Nivel). Machine learning for medical imaging (ophthalmology), NLP. Demonstrates the STAN model: researchers provide high-level AI consulting to private companies while maintaining CONICET affiliation.
- **Leonardo Gabriel Perpetuo (CONICET researcher)** — Studies social implications of AI programming in startups and spin-offs within Argentine technology parks and poles.
- **Federico Ariel (CONICET)** — Received UNESCO-AI Fozan International Prize (2023) for biotechnology contributions.

### Key Programs

- **STAN (Servicios Tecnológicos de Alto Nivel)** — Framework allowing CONICET researchers to offer specialized tech services to private industry. Direct science-to-business bridge.
- **CONICET Vinculación Tecnológica** — Office for technology transfer and industry partnerships.
- CONICET has historically promoted "spin-off" entrepreneurial initiatives from its research community (confirmed in 2018/2019 management reports).

**Strengths:** Deep scientific talent pool, strong in biotech, health AI, agricultural science. International collaborations (INRIA, KU Leuven, Medical University of Vienna).
**Gaps:** Limited structured commercialization pathways; spin-offs are rare exceptions rather than systematic output.

---

## 2. INTI (Instituto Nacional de Tecnología Industrial)

**Role:** National industrial technology institute, under the Ministry of Economy. Three pillars of Argentina's National Quality System.

### Key Capabilities

- **Metrología y Calidad** — National Metrology Institute (INM). Maintains national measurement standards per the International System of Units. Signatory to CIPM-MRA for international mutual recognition of measurements. Only public certification body in Argentina.
- **Centros Tecnológicos** — Network of technology centers across Argentina serving industry.
- **Certification** — Products, processes, management systems, and labor competencies (both mandatory and voluntary).
- **Reliau** — Network of INTI-supervised laboratories serving the automotive industry.
- **REDALOA** — Argentine Network of Official Food Analysis Laboratories.
- **Training & Capacitación** — University-level training programs (3-year programs running 2025-2028).

### AI/Innovation Initiatives

- INTI participates in **INNOVAR** (National Innovation Contest) alongside INTA and INET in the "Technical and Agricultural Schools" category.
- Active participation in **SAIA** (Sociedad Argentina de Inteligencia Artificial) conferences (2025).

**Gaps:** No visible dedicated AI research program. Primarily a standards/quality/certification body rather than an innovation driver for AI.

---

## 3. INTA (Instituto Nacional de Tecnología Agropecuaria)

**Role:** National agricultural technology institute. Argentina's key AgriTech research body.

### AI/Tech Innovations

- **Precision Agriculture at INTA Manfredi** — Hosts the International Congress of Precision Agriculture (20th edition, Aug 2024, 800+ attendees). Showcases AI in:
  - **Harvesting:** AI, automation, and robotics integrated into harvesting machinery
  - **Spraying:** Selective application systems, traceability platforms, drone-based targeted dispersal
  - **Seeding:** Electronic AgTech solutions for variable-rate input management
  - **Fertilization:** Data and sensor-based strategies
  - **Grain Storage:** AgTech solutions for quality assurance
  - **Drones:** Growing adoption for crop monitoring, phytosanitary application, seeding

- **Tripartite AI Project (2024):** INTA + Talleres Metalúrgicos Crucianelli + Leaf Agrotronics developing direct seeding and precision agriculture with AI and robotics. Goal: position Argentina as leader in agricultural innovation exports. Includes R&D, field implementation, and farmer training.

- **Hernán Ferrari (INTA specialist):** Leading agricultural mechanization + AI integration research.

**Strengths:** Strong real-world agricultural data, field testing infrastructure, farmer networks. The 2024 congress showed growing AgTech ecosystem adoption.
**Gaps:** AI implementation still "incipient" per experts. Blockchain and robotics adoption limited. Technology accessibility remains a challenge for smaller producers. Need for more training at multiple levels.

---

## 4. Fundación Argentina de Nanotecnología (FAN)

**Role:** Foundation promoting nanotechnology development and transfer.

### Current Programs

- **Postgraduate Program in Bio and Nanotechnology (2026)** — New course for professionals in science, technology, and health.
- **AOTS Argentina collaboration (2026)** — Exploring partnerships for technology transfer.
- **Space at Centro Atómico** — New building for the Institute of Nanoscience and Nanotechnology under construction (funded by Ministry of Science).
- **Federal Bio/Nanotechnology Promotion Program** — Launched 2023 in Rosario with $3.8 billion ARS investment. Includes support for science-based enterprises through accelerators ($40M USD via World Bank program over 4 years).

**Strengths:** Active training programs, government backing, international connections (Japan/AOTS).
**Gaps:** Focused narrowly on nano/bio — limited AI integration in current programs.

---

## 5. Asociación Argentina de Biomateriales

**Role:** Professional association for biomaterials research in Argentina.

**Status:** Limited public information found. Likely small academic society connecting researchers in biomaterials science. No visible AI integration or major tech transfer programs identified.

---

## 6. LEMEJ (Laboratorio de Ensayos de Materiales y Estructuras)

**Role:** Materials and structural testing laboratory.

**Status:** Limited public information found in searches. Likely associated with a university (possibly UTN or UBA) providing materials testing services. No visible AI/tech innovation programs identified.

---

## 7. Argentine Universities — AI Labs & Tech Transfer

### UBA (Universidad de Buenos Aires)
- Produces large pipeline of engineers, data scientists, and product managers.
- No specific AI spin-off identified from searches, but strong research output.

### UNLP (Universidad Nacional de La Plata)
- Active in scientific research, no specific AI spin-offs found.

### UTN (Universidad Tecnológica Nacional)
- Engineering-focused; LEMEJ may be associated here.

### ITBA (Instituto Tecnológico de Buenos Aires)
- Private engineering university; known for industry connections.

### UNICEN (Universidad Nacional del Centro de la Provincia de Buenos Aires)
- **PLADEMA Institute** — Birthplace of Retinar AI spin-off. Active AI research in medical imaging, computer vision, NLP.
- **Yatiris Lab** — Machine learning research group.
- José Ignacio Orlando (CONICET/UNICEN) runs AI Labs at Arionkoder via STAN framework.

### Di Tella
- **Laboratorio de Inteligencia Artificial** at the Business School — hosts specialist seminars on AI research and applications.

### UNCUYO (Universidad Nacional de Cuyo)
- **Espacio de Bionanotecnología Aplicada** — $3B ARS investment. Platforms in nucleic acids, analytics, 3D printing/prototyping, cell culture, **robotics & mechatronics, data & AI**, and food engineering. Coworking model for tech transfer.

---

## 8. Government Programs for Science-to-Business

### Agencia I+D+i (formerly ANPCyT/FONCyT/FONARSEC)
- **National agency for R&D promotion and innovation financing.** Rector of science/technology financing policy.
- **PICTO IA (2023)** — $13.5M USD (via BID) for AI research networks and technology development consortia. Two lines:
  1. Scientific-technological projects in AI (research networks)
  2. Associative projects applying AI/Data Science for export capacity
- **Protocolo de Montevideo** — Ethical AI framework: transparent algorithms, no bias reproduction.
- Priority sectors: Agribusiness, Energy/Mining, Health, Knowledge Economy. Cross-cutting tech: ICT, space/satellite, biotech, nanotech, AI.

### Ley 26.270 / 27.685 — Bio and Nanotechnology Promotion Law
- Tax benefits for registered biotech/nano companies. $590M ARS in benefits granted as of 2023.

### Ley de Economía del Conocimiento (Knowledge Economy Law)
- Tax incentives for tech companies. Knowledge economy is Argentina's **3rd largest export sector**.

### RIGI (Régimen de Incentivos para Grandes Inversiones, 2024)
- 25% fixed income tax, VAT incentives, customs relief, 30-year regulatory stability.
- Applies to technology sector. $200M USD minimum investment. $33.9B projected investments by Oct 2025.

### INNOVAR (National Innovation Contest)
- Categories: Design, Applied Research, Sustainability/Energy, Food, **Robotics + AI**, SMEs, University Innovation, Technical Schools.
- Includes INTI, INTA, INET participation.

### Programa RAICES
- Program for Argentine researchers abroad to maintain connections with national science system.

### Programa Federal Construir Ciencia
- Federal funding for science infrastructure across provinces (e.g., UNCUYO bionanotech space).

---

## 9. Argentine Tech Ecosystem Overview

### Key Metrics

| Metric | Value |
|--------|-------|
| Unicorns produced | 12 (most in LatAm after Brazil/Mexico) |
| VC raised in 2024 | $418M (one of only 3 LatAm countries with growth) |
| Total startup funding | $585M+ |
| Share of LatAm deep tech startups | 30% (despite only 5% of VC) |
| Software developers in BA | 115,000+ |
| Tech companies in BA | 1,200+ |
| GDP growth 2025 | 4.4% (fastest in LatAm) |
| Global startup ecosystem rank | #46 (2025) |

### Notable Companies with Scientific/Research Origins

- **Bioceres** — Agricultural biotech company, CONICET/university research origins. NASDAQ-listed.
- **Satellogic** — Satellite imagery company, strong ties to Argentine scientific community. NASDAQ-listed.
- **Globant** — Multinational IT/AI giant, originated in Buenos Aires.
- **MercadoLibre** — "Amazon of LatAm," Argentine origin.
- **Auth0** — Identity security (acquired by Okta).
- **Ualá** — Fintech, $300M raise in 2024.

---

## 10. GAPS — What a Bootcamp Could Fill

### Critical Gaps Identified

1. **Science-to-Business Translation Skills**
   - Argentine scientists produce world-class research but lack training in commercialization, business model design, IP strategy, and pitch skills.
   - CONICET STANs exist but are rare; most researchers don't know how to structure a spin-off.

2. **AI Application Layer Missing**
   - Strong AI research exists (PLADEMA, Yatiris Lab, Di Tella AI Lab) but the bridge from research to product is weak.
   - Researchers know ML/deep learning but not product development, UX, or go-to-market.

3. **AgriTech AI Gap**
   - INTA has the agricultural domain expertise and field infrastructure but limited AI engineering capacity.
   - Precision agriculture AI adoption is "incipient" — massive opportunity in Argentina's core economic sector.

4. **Fragmented Ecosystem**
   - Institutions (CONICET, INTI, INTA, FAN, universities) operate largely independently.
   - No integrated program connecting AI researchers → domain experts → commercialization support.

5. **No Systematic AI Bootcamp for Scientists**
   - Existing programs focus on either pure research (PICTO IA) or general startup support (Agencia I+D+i accelerators).
   - No program specifically trains scientists in practical AI/ML product development with commercialization focus.

6. **Bio/Nano to AI Bridge**
   - FAN's programs are bio/nano-focused. An AI bootcamp could add the data science/ML layer to existing nanotechnology and biomaterials research.

7. **Brain Drain Risk**
   - Argentine researchers face economic instability; many leave for Europe/US.
   - A bootcamp that teaches commercialization could help retain talent by creating viable career paths in-country.

8. **Ethical AI Framework Exists but Implementation Lags**
   - Protocolo de Montevideo establishes ethical AI principles, but practical implementation training is absent.

9. **Regional Inequality**
   - Most innovation concentrated in Buenos Aires and Córdoba.
   - Federal programs (Construir Ciencia) exist but AI capacity-building is not reaching interior provinces.

10. **IP & Patent Strategy**
    - Argentine scientists file relatively few AI patents ($3M in AI investments, 1 AI patent in 2024 per AI World data).
    - Training in patent strategy and IP protection is a clear gap.

### Bootcamp Opportunity Summary

| Area | Current State | Bootcamp Value-Add |
|------|--------------|-------------------|
| AI Research | Strong (CONICET, universities) | Product development skills |
| Commercialization | Weak/fragmented | Structured business training |
| AgriTech AI | Incipient | Domain-specific AI applications |
| Health AI | Emerging (Retinar model) | Scalable product frameworks |
| Deep Tech Startups | 30% of LatAm, underfunded | Investor-readiness training |
| Ethical AI | Policy exists (Montevideo Protocol) | Practical implementation |
| IP Strategy | Minimal | Patent & licensing training |
| Regional Reach | BA-centric | Federal bootcamp delivery |

---

## Bottom Line

Argentina has exceptional scientific talent and a growing tech ecosystem (12 unicorns, $585M+ funding, 30% of LatAm deep tech), but the critical gap is the **translation layer** between world-class research and market-ready AI products. A bootcamp targeting scientists with practical AI product development + commercialization training could unlock significant latent value, especially in AgriTech and Health AI where Argentina already has strong domain expertise and institutional infrastructure.
