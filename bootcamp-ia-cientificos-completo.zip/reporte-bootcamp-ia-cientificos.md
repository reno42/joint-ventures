# Bootcamp IA para Científicos — Reporte Completo
## Joint Venture: NETI × Futuraria

> NETI (No Está Todo Inventado) — Innovación regional Argentina
> Futuraria — Agencia de IA, Perú (futuraria.com)

---

## 1. COMPETIDORES Y PROGRAMAS EXISTENTES

### 1.1 Programas Globales

| Programa | País | Formato | Duración | Precio | Target |
|---|---|---|---|---|---|
| **NSF I-Corps** | USA | Bootcamp intensivo | 7 semanas | Gratis (subvención NSF) | Investigadores universitarios |
| **DeepLearning.AI** | Global | Online courses | 4-16 semanas | $49-79/mes | General (no específico ciencia) |
| **Fast.ai** | Global | Online | 7 semanas | Gratis | Programadores, no científicos |
| **Coursera for Science** | Global | Online | Variable | $39-79/mes | General académico |
| **MIT Bootcamps** | USA | Intensivo | 1 semana | $5,000-15,000 | Profesionales |
| **Singularity University** | USA | Intensivo | 1-10 días | $5,000-50,000 | Ejecutivos |
| **Creative Destruction Lab** | Canadá | Mentoría | 9 meses | Equity-based | Startups ciencia |
| **Y Combinator** | USA | Aceleradora | 3 meses | $500K equity | Startups |

### 1.2 Programas LATAM

| Programa | País | Formato | Duración | Precio | Target |
|---|---|---|---|---|---|
| **Laboratoria** | Perú/Chile/Mx | Bootcamp | 6 meses | Gratis (beca) | Mujeres en tech |
| **DSRP Data Science** | Perú | Bootcamp | 12 semanas | $1,500-3,000 | Profesionales |
| **Platzi** | LATAM | Online | Variable | $20-30/mes | General tech |
| **Acámica** | Argentina | Bootcamp | 12-24 semanas | $1,000-4,000 | Desarrolladores |
| **Henry Bootcamp** | Argentina | Online | 4 meses | Income share | Desarrolladores |
| **Ualá Academy** | Argentina | Bootcamp | Variable | Gratis | Fintech |
| **CONICET Tech Transfer** | Argentina | Programa | Variable | Gratis | Investigadores |
| **Wayra (Telefónica)** | LATAM | Aceleradora | 6 meses | Equity | Startups tech |
| **UTEC Ventures** | Perú | Aceleradora | 4 meses | Equity | Startups |
| **EmprendeUP** | Perú | Incubadora | Variable | Gratis | Universitarios |

### 1.3 Vacío de Mercado

**Ningún programa en LATAM enseña IA específicamente a científicos para acelerar investigación.** Todos los bootcamps existentes:
- Enseñan IA a programadores (no a científicos)
- Son para emprendedores generales (no investigación)
- No tienen componente de simulación/modelado científico
- No usan modelos preentrenados de dominio científico

**Oportunidad:** Primer bootcamp LATAM de IA para Investigadores.

---

## 2. MODELOS IA PARA CIENCIA

### 2.1 Simulación Molecular y Modelado Atomístico

| Modelo | Qué hace | Acceso | Dificultad | Datos necesarios |
|---|---|---|---|---|
| **MACE-MP/OFF** | Potenciales interatómicos ML, simulación molecular 1000x más rápida que DFT | [GitHub](https://github.com/ACEsuit/mace) · `pip install mace-torch` | Media | Cero (preentrenado) |
| **Meta OMol25/UMA** | Potenciales atómicos universales, "AlphaFold de materiales" | [GitHub](https://github.com/FAIR-Chem) · [Rowan](https://rowansci.com) | Baja-Media | Cero |
| **SchNet / DimeNet / PaiNN** | Redes neuronales para propiedades moleculares | [torch-geometric](https://pytorch-geometric.readthedocs.io/) | Media | Cero (preentrenado QM9) |
| **ASE (Atomic Simulation Environment)** | Wrapper unificado para potenciales ML | `pip install ase` | Baja | N/A (framework) |

### 2.2 Materiales

| Modelo | Qué hace | Acceso | Dificultad |
|---|---|---|---|
| **IBM FM4M** | Modelo fundacional multi-modal para descubrimiento de materiales | [GitHub](https://github.com/IBM/materials) · [HuggingFace](https://huggingface.co/collections/ibm/materials-673465deacbdf38d9c0c6303) | Baja-Media |
| **MatGL (M3GNet, CHGNet)** | Librería graph DL para ciencia de materiales | GitHub | Media |
| **Open Catalyst (Meta/Microsoft)** | Modelos para descubrimiento de catalizadores | [opencatalystproject.org](https://opencatalystproject.org) | Media-Alta |
| **Google DeepMind GNoME** | Predicción de 2.2M estructuras cristalinas | Publicación académica | Alta |

### 2.3 Biomedicina y Fármacos

| Modelo | Qué hace | Acceso | Dificultad |
|---|---|---|---|
| **AlphaFold 3** | Estructura 3D de proteínas, DNA, RNA, ligandos | [alphafoldserver.com](https://alphafoldserver.com) · [GitHub](https://github.com/google-deepmind/alphafold3) | Baja (server) |
| **ESM (Meta)** | Modelos de lenguaje de proteínas | [GitHub](https://github.com/facebookresearch/esm) · HuggingFace | Media |
| **Deep Origin / Balto** | Drug discovery sin código, docking, toxicidad | [deeporigin.com](https://deeporigin.com) | **Baja** |
| **Insilico Medicine** | Diseño de fármacos con IA (target → Phase II en 30 meses) | Comercial | Media |

### 2.4 Plataformas Sin Código

| Plataforma | Dominio | Acceso | Link |
|---|---|---|---|
| **Rowan** | Simulación molecular completa | Web, login con Google | [rowansci.com](https://rowansci.com) |
| **AlphaFold Server** | Estructura de proteínas | Web, gratis | [alphafoldserver.com](https://alphafoldserver.com) |
| **IBM FM4M Demo** | Propiedades de materiales | HuggingFace Space | [HuggingFace](https://huggingface.co/ibm-research) |
| **HuggingFace Hub** | Todos los dominios | Web + inference API | [huggingface.co](https://huggingface.co) |
| **Google Colab** | Todos los dominios | Notebook gratis con GPU | [colab.research.google.com](https://colab.research.google.com) |

---

## 3. FORMATOS DE BOOTCAMP

### 3.1 Duración y Formatos Existentes

| Formato | Duración | Ejemplos | Precio típico |
|---|---|---|---|
| **Flash (1 día)** | 8 horas | Hackathons, sprints | $50-200 USD |
| **Weekend Bootcamp** | 2 días (16h) | Weekend of Innovation, MLH | $100-500 USD |
| **Sprint (1 semana)** | 5 días (40h) | MIT Bootcamps, Singularity | $500-5,000 USD |
| **Intensivo (2-4 semanas)** | Full-time | Laboratoria, Henry | $500-3,000 USD |
| **Bootcamp (8-12 semanas)** | Part-time/full-time | I-Corps, DSRP | $1,500-15,000 USD |
| **Programa largo (6+ meses)** | Part-time | Creative Destruction Lab | Equity o $5,000+ |

### 3.2 Formatos Recomendados para NETI × Futuraria

#### 🔥 Formato Flash (1 día) — "IA para tu Investigación en 8 horas"
- **Mañana:** Intro + herramientas sin código (Rowan, AlphaFold, HuggingFace)
- **Tarde:** Hands-on con tu propia investigación (traer datos/reto)
- **Precio:** $80-150 USD
- **Objetivo:** Generar leads, demostrar valor inmediato

#### 🚀 Formato Weekend (2 días) — "Sprint de Prototipado con IA"
- **Día 1:** Modelos IA + herramientas + casos de uso
- **Día 2:** Prototipar solución para tu investigación + pitch
- **Precio:** $200-400 USD
- **Objetivo:** Resultado tangible (prototipo funcional)

#### 🎓 Formato Intensivo (1 semana) — "Bootcamp IA Científicos"
- **Lunes:** Fundamentos IA + landscape de modelos
- **Martes:** Simulación molecular con MACE/Rowan
- **Miércoles:** Análisis de datos experimentales
- **Jueves:** Prototipado rápido con modelos preentrenados
- **Viernes:** Presentación de proyectos + próximos pasos
- **Precio:** $800-2,000 USD
- **Objetivo:** Transformación completa del workflow

#### 🏗️ Formato Programa (8-12 semanas) — "De Laboratorio a Producto"
- Basado en I-Corps + ETI
- 100 entrevistas a clientes potenciales
- Prototipado iterativo
- Mentoría semanal
- **Precio:** $3,000-8,000 USD o equity
- **Objetivo:** Lanzar startup/prototipo comercializable

---

## 4. PLAYBOOKS

### 4.1 Cómo Atraer Participantes

#### Fase 1: Awareness (4-6 semanas antes)
1. **Contenido en LinkedIn/Twitter:** Publicar casos de éxito de IA en ciencia (3x/semana)
2. **Webinars gratuitos:** "Cómo AlphaFold cambió la biología" (1 hora, gratuito)
3. **Alianzas institucionales:** Contactar CONICET, universidades, asociaciones científicas
4. **Newsletter:** Serie de emails con "5 formas en que la IA acelera tu investigación"
5. **Testimonios:** Videos cortos de científicos que usan IA

#### Fase 2: Consideración (2-4 semanas antes)
1. **Caso de estudio detallado:** "De 2 años a 2 meses: simulación de materiales con MACE"
2. **Demo en vivo:** Rowan + AlphaFold en acción (YouTube Live)
3. **Descuento early bird:** 20% para primeros 10 inscritos
4. **Referidos:** Descuento adicional por traer colega

#### Fase 3: Conversión (última semana)
1. **Scarcity real:** "Quedan 5 lugares" (si es verdad)
2. **Garantía:** "Si no aprendes algo útil, te devolvemos el dinero"
3. **1-a-1:** Llamadas de 15 min con interesados para resolver dudas

#### Fase 4: Post-bootcamp
1. **Comunidad privada:** Slack/Discord de alumni
2. **Mentoría mensual:** Sesiones de seguimiento
3. **Newsletter exclusiva:** Nuevos modelos, papers, herramientas
4. **Programa avanzado:** Para quienes quieren profundizar

### 4.2 Playbook de Interacción Durante el Bootcamp

#### Principios ETI (Estar, Transformar, Iterar)
1. **Estar:** Inmersión total en el problema del científico (no imponer soluciones)
2. **Transformar:** Manos a la tecla — cada hora debe producir algo tangible
3. **Iterar:** Feedback inmediato, ciclo corto de prueba-error

#### Estructura de Sesión (cada 2 horas)
- **15 min:** Demo en vivo del facilitador
- **60 min:** Hands-on (participantes trabajan con sus datos)
- **30 min:** Share & feedback (cada equipo muestra avance)
- **15 min:** Siguiente paso + break

#### Reglas de Oro
- **Nunca teoría sin práctica** — cada concepto se aplica inmediatamente
- **Traer tu propio reto** — no ejercicios genéricos
- **Equipos de 2-3** — nunca solo
- **Entregable por sesión** — algo que puedas mostrar

---

## 5. NICHOS POR MODELO

### 5.1 Mapa de Nichos

| Nicho Industrial | Modelos IA Aplicables | Dolor del Mercado | Potencial |
|---|---|---|---|
| **🔋 Baterías y Almacenamiento** | MACE-MP, IBM FM4M, Open Catalyst | Transición energética, demanda explosiva | ⭐⭐⭐⭐⭐ |
| **💊 Fármacos y Biomedicina** | AlphaFold 3, ESM, Deep Origin | Tiempos de 10-15 años, costos $2.6B | ⭐⭐⭐⭐⭐ |
| **🧪 Catalizadores (H₂ verde)** | Open Catalyst, MACE | Descarbonización, urgencia climática | ⭐⭐⭐⭐ |
| **🧬 Enzimas Industriales** | ESM, AlphaFold | Bioplásticos, biocombustibles | ⭐⭐⭐⭐ |
| **🔩 Aleaciones Ligeras** | MACE-MP, IBM FM4M | Aeroespacial, automotive | ⭐⭐⭐⭐ |
| **🏭 Materiales Avanzados** | IBM FM4M, GNoME, MatGL | Semiconductores, superconductores | ⭐⭐⭐⭐ |
| **🌿 Biomateriales** | AlphaFold, ESM | Implantes, ingeniería de tejidos | ⭐⭐⭐ |
| **❄️ Refrigeración** | MACE-MP | Eficiencia energética | ⭐⭐⭐ |
| **🌾 AgTech** | MACE-MP, modelos de suelos | Agricultura de precisión | ⭐⭐⭐ |

### 5.2 Nichos Recomendados para Piloto

**Top 3 para empezar:**

1. **🔋 Baterías** — Mayor demanda, modelos más maduros (IBM FM4M tiene demo específica)
2. **💊 Fármacos** — Mayor impacto, AlphaFold ya tiene 2M+ usuarios, demostrado
3. **🧪 Catalizadores H₂** — Urgencia climática, Open Catalyst tiene datos masivos

**Estrategia:** Empezar con **un nicho** (baterías o fármacos), lograr caso de éxito, luego expandir.

---

## 6. MODELO DE NEGOCIO

### 6.1 Joint Venture NETI × Futuraria

| NETI aporta (Argentina) | Futuraria aporta (Perú) |
|---|---|
| Red de científicos e instituciones | Stack tecnológico (n8n + Supabase) |
| Presencia en el ecosistema científico AR | Plataforma de automatización |
| Contactos CONICET, INTI, universidades | Consultoría ENIA (regulación IA) |
| Metodología ETI | Operaciones y marketing digital |
| Innovación regional | Escala LATAM |

### 6.2 Revenue Streams

1. **Bootcamps:** $150-2,000 USD por participante (según formato)
2. **Consultoría ENIA:** Compliance para empresas con IA (Perú → exportar a LATAM)
3. **Automatización n8n:** Workflows para laboratorios
4. **Comunidad premium:** Suscripción mensual $30-50
5. **Corporate training:** B2B para empresas pharma/materials

---

## 7. PRÓXIMOS PASOS

1. ✅ Investigación de mercado completada
2. ⏳ Definir nicho piloto (reunión hoy 15 mayo)
3. ⏳ Crear landing page para testear demanda
4. ⏳ Diseñar formato flash (1 día) para primer piloto
5. ⏳ Contactar 3 instituciones para piloto (CONICET, Fundación Nanotecnología, Biomateriales)
6. ⏳ Armar primer Colab notebook para el bootcamp
