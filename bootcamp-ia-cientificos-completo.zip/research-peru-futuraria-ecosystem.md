# Futuraria & Peruvian Tech/AI Ecosystem — Research Report

**Date:** May 15, 2026  
**Prepared by:** Research Subagent

---

## 1. Futuraria — Company Profile

### What Is Futuraria?

**Futuraria** (futuraria.com) is a **Peruvian AI agency** founded by **Renzo Perez Bartra**. Based in Lima, Peru, it positions itself as an "Agencia de IA, Automatizaciones y Desarrollo Web" (AI Agency, Automations, and Web Development).

### Core Services

Futuraria offers six main service lines:

1. **AI Automations for Marketing**
   - AI copywriter and scriptwriter agents
   - Social media posting and customer service automation
   - Competitor research, trending topics, content hooks
   - Graphic design automation
   - Person cloning for YouTube, Instagram, TikTok, LinkedIn, X, and podcasts (voice and/or video)

2. **Sales Agents & Omnichannel Chatbots**
   - Chat and call-based sales
   - Customer service and success connected to help centers
   - Competitor monitoring (pricing, offers, content)
   - Booking, confirmation, and reminders via WhatsApp/email
   - Re-purchase and product refill reminders

3. **Document & Internal Process Management**
   - Automated contracts, accounting documents, and reports
   - Medical/therapeutic test automation
   - Onboarding workflows
   - Meeting assistants that record, summarize, transcribe, and generate tasks

4. **Websites, Ecommerce, Client Portals & MVPs**
   - Landing pages and websites with CMS
   - Blogs and e-commerce
   - Virtual offices, intranets, help centers
   - MVPs for startups
   - CRM integrations

5. **Branding**
   - Brand development from scratch
   - Brand renovation and standardization with manuals
   - Concepts and pitches for VC investors

6. **Digital Transformation & AI Adoption**
   - Bilingual AI workshops and training (English/Spanish)
   - Hands-on workshops in GenAI, AI Workflows, and Autonomous Agents
   - Global adoption strategies

### Strategic Differentiator: ENIA Compliance Consulting

Futuraria has built a **significant content moat** around Peru's AI regulatory framework:

- **ENIA 2026-2030** (Estrategia Nacional de Inteligencia Artificial) — Peru's national AI strategy
- **Ley 31814** (July 2023) — Peru's AI promotion law
- **DS 115-2025-PCM** (September 2025) — The implementing regulation

Futuraria operates **enia.futuraria.com**, a dedicated subdomain providing:
- Guides on ENIA compliance for businesses
- Risk classification explanations (Prohibited / High Risk / Acceptable)
- Compliance deadline tracking by sector (Sept 2026–2029)
- Blog content positioning Renzo Perez Bartra as a thought leader on AI regulation in LATAM
- Comparative analyses: Peru vs. Chile vs. Colombia vs. Brazil AI regulation

**Compliance consulting services include:**
- AI Systems Audit (inventory, risk classification, gap analysis)
- Compliance Roadmap design
- OIA (Oficial de Inteligencia Artificial) preparation
- NTP-ISO/IEC 42001 implementation support
- High-risk impact assessments

### Client Testimonials

- **Frames 24/7 & Magia y Brillo** (production companies) — AI products, automations, and marketing AI training
- **Policlínico Peruano Japonés** — Automated diagnostic workflows for therapists, saving weeks of work per therapist
- **Jockey Plaza (via Piero Pascual)** — Marketing automations reducing production costs by 30%+ with fully remote operations

### Workshops & Community

Futuraria runs free workshops globally (bilingual):
- "AI for Marketing Agencies" masterclass (Canada 9AM / Peru 11AM)
- "MVPs con VibeCoding" lab session (Colombia/Peru)
- "GPTs para Automatizar Procesos" lab session
- Part of **Colectidea** innovation week events

### Tech Stack

- **n8n Community Edition v2.10.4** (hosted on Railway) — workflow automation
- **Supabase** — database backend
- Focus on making AI accessible to non-technical teams

### Key Insight

Futuraria is positioning itself at the intersection of **AI implementation** and **regulatory compliance** — a smart niche given that Peru is the first LATAM country with a fully enacted AI law. The ENIA subdomain is essentially a content marketing play that establishes authority and generates compliance consulting leads.

---

## 2. Peruvian AI/Tech Ecosystem

### 2.1 Regulatory Environment (The ENIA Framework)

Peru is **the most advanced country in LATAM** for AI regulation:

| Element | Details |
|---------|---------|
| **Ley 31814** | AI promotion law, approved July 2023 |
| **DS 115-2025-PCM** | Implementing regulation, 36 articles, 6 titles, effective Sept 2025 |
| **ENIA 2026-2030** | National AI Strategy, approved May 2026 |
| **Ley 32314** | Aggravating criminal penalties for crimes committed with AI |
| **Authority** | SGTD (PCM) directs; INDECOPI and ANPDP sanction; Contraloría oversees public sector |

**Risk Classification (3 levels):**
- **Prohibited:** Subliminal manipulation, autonomous lethal capacity, mass surveillance without legal basis, inferring sensitive data from biometrics, real-time biometric ID in public spaces, crime prediction based on personality profiles
- **High Risk:** Critical infrastructure, educational evaluation of minors, HR decisions, social program access, credit scoring, health diagnosis/access, emotion inference in workplaces/education
- **Acceptable:** Everything else, with general principles (ethics, transparency, non-discrimination)

**Compliance Deadlines by Sector:**
- Sept 2026: Health, Education, Justice, Security, Economy & Finance
- Sept 2027: Transport, Commerce, Labor (including MYPES 150-1700 UIT)
- Sept 2028: Production, Agriculture, Energy, Mining (including microenterprises <150 UIT)
- Sept 2029: All remaining sectors

**Incentives (Articles 16-21):**
- Regulatory sandboxes
- MIPYME support (fairs, events, innovation challenges, financing)
- Cloud computing access for AI development
- Open-source recognition programs

### 2.2 AI Startups & Companies in Peru

**Key sectors leading AI adoption:**

**Fintech (most visible):**
- Alternative credit scoring using non-traditional data
- Real-time fraud detection
- Automated customer service (chatbots)
- Personalized financial product recommendations
- Note: Credit scoring automation is classified as high-risk under ENIA

**Agtech:**
- Pest/disease detection via computer vision on crop images
- Irrigation optimization with IoT sensors and predictive models
- Harvest yield prediction using climate and satellite data
- Supply chain traceability with AI + blockchain

**Healthtech:**
- AI-assisted diagnosis
- Hospital management optimization
- Telemedicine platforms
- Note: Health AI systems are high-risk under ENIA, requiring mandatory human oversight

**Edtech & Govtech:**
- Personalized learning platforms
- Automated administrative processes
- Public service delivery improvement

**Notable companies/initiatives:**
- **Reactor** — Peruvian startup (founded by Daniel Rivas) specializing in water resource restoration and plastic elimination, expanded to Madrid (Jan 2024)
- **Perú Tech Week 2025** — Major tech/AI event bringing together experts, startups, and investors
- **InnovaESAN** — AI innovation within the ESAN ecosystem
- **Ecosistema Startup Peruano** — Active community organizing events and connecting founders

### 2.3 Universities & AI/Tech Programs

| University | Known For |
|------------|-----------|
| **PUCP** (Pontificia Universidad Católica del Perú) | Top CS/engineering programs, research in AI and data science |
| **UNI** (Universidad Nacional de Ingeniería) | Engineering powerhouse, strong technical foundation |
| **UTEC** (Universidad de Ingeniería y Tecnología) | Newer, innovation-focused, strong ties to startup ecosystem |
| **UPC** (Universidad Peruana de Ciencias Aplicadas) | Partnerships with bootcamps (e.g., Laboratoria), applied tech programs |

**Research ecosystem:**
- **CONCYTEC** (Consejo Nacional de Ciencia, Tecnología e Innovación Tecnológica) — National science and technology council
- **CNIDIA** (Centro Nacional de Innovación Digital e Inteligencia Artificial) — National center for digital innovation and AI, established under the ENIA framework
- Multiple research groups working on NLP, computer vision, and machine learning applications for Peruvian contexts (agriculture, mining, biodiversity)

### 2.4 Incubators & Accelerators

| Organization | Focus |
|-------------|-------|
| **UTEC Ventures** | University-linked accelerator, early-stage startups |
| **EmprendeUP** | UPCH-linked incubator, broad sector focus |
| **Wayra** (Telefónica) | Corporate accelerator, telecom-adjacent startups |
| **NXTP Labs** | Regional accelerator with Peru presence |
| **StartUp Peru** (PRODUCE) | Government-backed startup program |
| **Innóvate Perú** (PRODUCE) | Innovation vouchers and co-financing for R&D |
| **Colectidea** | Innovation week events, community building |

### 2.5 Government Programs

| Program | Details |
|---------|---------|
| **Innóvate Perú** | PRODUCE program providing co-financing for innovation projects in companies |
| **StartUp Peru** | Competitive grants for early-stage startups |
| **CONCYTEC** | National science/technology/innovation council, funds research |
| **PRODUCE** (Ministerio de la Producción) | Ministry overseeing industry, innovation, and SME development |
| **ENIA 2026-2030** | National AI Strategy with 4 pillars: Talent, Innovation, Ethical Framework, Citizen Participation |
| **CNIDIA** | National AI Innovation Center, bridge between government and private sector |
| **Regulatory Sandboxes** | Any AI developer can apply to participate in controlled testing environments |

### 2.6 Key Events & Community

- **Perú Tech Week 2025** — Major annual tech event
- **Hackathon ATU 2026** — Mobility-focused hackathon
- **Innovahack 2026** — Innovation hackathon
- **Colectidea Innovation Week** — Free workshops and lab sessions
- **Ecosistema Startup Peruano** — Active community with events and networking

---

## 3. Bootcamps & Training in Peru

### 3.1 Existing Tech Bootcamps

| Bootcamp | Focus | Notes |
|----------|-------|-------|
| **Laboratoria** | Women in tech — UX, web dev, data analysis | Founded in Peru, expanded across LATAM. Free program for women. New "Skill Up Data" program. Partners with UPC. 6-week "Activa tu carrera" program + longer digital skills track. |
| **Data Science Research Perú (DSRP)** | Data science & AI bootcamps | 4-month data analysis bootcamp. Hybrid modality. Based at datascience.pe |
| **HackSpace Academy** | Programming bootcamps | Coding and web development focused |
| **Acámica** | Online tech education | Various tech programs (may have been absorbed/merged) |

### 3.2 Data Science / AI Training Programs

- **Laboratoria's Skill Up Data** — New data science track for women, with PhD-level instructors (e.g., Gladys Choque, doctoral student at University of São Paulo)
- **DSRP Bootcamp** — 4-month intensive data analysis program
- **University continuing education** — PUCP, UTEC, UPC offer executive/professional development courses in AI and data science
- **Futuraria's own workshops** — Bilingual (EN/ES) hands-on workshops in GenAI, AI Workflows, and Autonomous Agents

### 3.3 Science-to-Business Programs

- **Innóvate Perú** — Government co-financing for companies to do R&D
- **UTEC Ventures** — Bridges university research to startup formation
- **CONCYTEC grants** — Fund research with commercialization potential
- **ENIA incentives** — Cloud computing credits, open-source recognition, regulatory sandbox access

---

## 4. LATAM Joint Venture Opportunities: Argentina ↔ Peru

### 4.1 Complementary Strengths

| Dimension | Argentina 🇦🇷 | Peru 🇵🇪 |
|-----------|--------------|----------|
| **AI Research** | Strong academic tradition (UBA, ITBA, CONICET), deep ML/NLP talent | Growing, focused on applied AI (agriculture, mining, biodiversity) |
| **Startup Ecosystem** | More mature, multiple unicorns (Globant, MercadoLibre, Ualá) | Earlier stage but fast-growing, strong government support |
| **Regulation** | Still developing AI-specific framework | Most advanced in LATAM (Ley 31814 + ENIA 2026-2030) |
| **Talent Cost** | Devalued peso = competitive costs | Moderate costs, growing talent pool |
| **Market** | 46M people, high digital adoption | 34M people, growing digital economy |
| **Key Industries** | Fintech, SaaS, e-commerce, gaming | Fintech, agtech, mining tech, healthtech |
| **Government Support** | Mixed (instability vs. past innovation programs) | Strong and consistent (PRODUCE, CONCYTEC, ENIA) |
| **Language** | Spanish (Rioplatense) | Spanish (neutral/Lima standard) |

### 4.2 Why Argentina-Peru Makes Sense

1. **Regulatory arbitrage opportunity:** Argentina can learn from Peru's ENIA framework; Peru can access Argentina's deeper AI talent pool
2. **Complementary sectors:** Argentina's fintech/SaaS expertise + Peru's agtech/mining tech needs
3. **Cost optimization:** Argentine developers at competitive rates serving Peruvian enterprise market
4. **Content & thought leadership:** Futuraria's ENIA expertise could be exported to help Argentine companies understand LATAM AI regulation
5. **Shared language, different markets:** Spanish-language content/services work across both, but each market has unique needs
6. **Time zone alignment:** Both in similar time zones (GMT-3 to GMT-5), enabling real-time collaboration

### 4.3 Potential Joint Venture Models

**Model 1: Argentina Dev Shop + Peru Sales/Compliance**
- Argentine engineers build AI solutions
- Futuraria handles Peru-side sales, ENIA compliance consulting, and client management
- Revenue share on Peruvian clients

**Model 2: Cross-Border AI Training**
- Joint bootcamp program leveraging Argentina's academic depth + Peru's regulatory framework
- Bilingual workshops (already a Futuraria strength)
- Target: Enterprise teams across LATAM

**Model 3: ENIA Compliance Export**
- Futuraria's ENIA expertise becomes a productized service
- Argentine companies operating in Peru (or planning to) need compliance guidance
- Expand to Chile, Colombia, Brazil as they develop their own AI regulations

**Model 4: Shared AI Agent Marketplace**
- Build reusable AI agents (sales bots, marketing automation, compliance checkers)
- Sell across both markets with localized configurations
- Use n8n + Supabase stack (already Futuraria's core) as the foundation

**Model 5: Startup Bridge Program**
- Argentine startups enter Peru through Futuraria's network
- Peruvian startups access Argentine talent and investment
- Joint pitch events, hackathons, demo days

### 4.4 Risks & Considerations

- **Currency volatility:** Argentina's economic instability creates pricing challenges
- **Regulatory divergence:** While Peru is ahead, other LATAM countries are catching up at different speeds
- **Cultural nuances:** Despite shared language, business cultures differ (Argentina more European-influenced, Peru more traditional)
- **Infrastructure:** Internet quality and reliability vary across regions
- **Competition:** Both markets face competition from Mexico, Colombia, Brazil, and Chile

---

## 5. Key Takeaways

### For Futuraria Specifically:

1. **The ENIA positioning is brilliant.** Peru is the first LATAM country with enacted AI law, and Futuraria is establishing itself as the go-to compliance/implementation partner. This is a time-limited first-mover advantage.

2. **The content strategy is working.** Multiple blog posts, ENIA subdomain, comparative analyses, and workshop events create a strong thought leadership pipeline.

3. **Workshop reach is global.** Bilingual workshops targeting Canada, Colombia, and Peru show ambition beyond just the Peruvian market.

4. **The n8n + Supabase stack is lean and scalable.** Good for a small agency that wants to stay nimble.

### For the Argentina-Peru JV:

5. **Timing is right.** Peru's AI regulation creates immediate demand; Argentina has the talent to serve it.

6. **Start with compliance consulting.** It's the most urgent need (Sept 2026 deadline for health/education/finance sectors).

7. **Expand to training.** Joint bootcamps and workshops are a natural next step once the compliance consulting relationship is established.

8. **Think product, not just services.** The goal should be building reusable tools/agents that scale across markets, not just billable hours.

---

*Sources: futuraria.com, enia.futuraria.com, laboratoria.la, datascience.pe, contxto.com, startupslatam.com, Instagram (various), and general knowledge of the LATAM tech ecosystem.*
